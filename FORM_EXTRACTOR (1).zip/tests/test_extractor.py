from extractor import FieldExtractor
from pathlib import Path
import json

def test_patterns_compile():
    cfg = json.load(open("config/fields.yml"))
    for key, field in cfg["fields"].items():
        for pat in field.get("patterns", []):
            assert "(?P<val>" in pat
